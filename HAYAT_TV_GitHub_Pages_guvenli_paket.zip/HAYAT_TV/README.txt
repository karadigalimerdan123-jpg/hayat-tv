HAYAT TV - GITHUB PAGES İÇİN GÜVENLİ ÖN İZLEME

YÜKLEME:
1. ZIP dosyasını telefonuna indirip çıkar.
2. İçindeki HAYAT_TV klasöründeki index.html dosyasını GitHub deposunun ana dizinine yükle.
3. İstersen README.txt dosyasını da yükle. ZIP dosyasını tek başına yüklemek siteyi çalıştırmaz.

BU SÜRÜMDE:
- HAYAT TV ana sayfası ve program kartları
- Yayın akışı
- Örnek haber kartları
- Saat ve tarih
- Kayıt/giriş ekranları (sunucu bağlantısı olmadığından devre dışı)
- Yönetici girişi (güvenli sunucu bağlantısı olmadığından devre dışı)

GÜVENLİK:
Bu statik GitHub Pages demosunda gerçek kullanıcı hesabı veya güvenli yönetici paneli bulunmaz. Herkese açık JavaScript dosyalarına yönetici parolası konulmaz. Gerçek üyelik ve yönetim için sunucu tarafı kimlik doğrulama ve veritabanı gerekir. Bu nedenle yönetici parolası bu pakete eklenmemiştir.

CANLI YAYIN:
"Yayına Başla" bölümü şu anda tasarım alanıdır, gerçek canlı yayın başlatmaz. Gerçek yayın kaynağı ve yayın hizmeti ayrıca bağlanmalıdır.

HABER / TELİF:
Haber kartları örnek tasarımdır; gerçek haberler doğrulanıp kaynakları eklenmeden yayımlanmamalıdır. Film ve çizgi filmler yalnızca yayın izni bulunan veya uygun lisanslı içeriklerden seçilmelidir.

Bu paket internet sitesini statik olarak yayımlamak içindir; canlı yayın ve sunucu tabanlı hesap özelliklerini sağlamaz.
